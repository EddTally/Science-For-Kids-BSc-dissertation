package lib;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import model.ScienceForKidsProfile;
import model.User;

public class SelectingTopic {

	private ScienceForKidsProfile model;	
	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;
	
	@Test
	public void SelectingTopicTest() {
		model = new ScienceForKidsProfile();
		new User();
		
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
		
		
		try {
			/* Testing Physics Test Topic */
			model.getTopic().setSubject("physics");
			model.getTopic().setSubjectYear(50);
			
			myStmt = myConn.prepareStatement("SELECT * FROM " + model.getTopic().getSubject().toLowerCase() + " WHERE topicYear =?");
			myStmt.setInt(1, model.getTopic().getSubjectYear());
			myRs = myStmt.executeQuery(); 
			myRs.next();
			assertEquals("This string should be 'Test Topic Contents1�Test Topic Contents2�Test Topic Contents3'", 
					"Test Topic Contents1�Test Topic Contents2�Test Topic Contents3",
					myRs.getString("topicContents"));
			
			/* Testing Biology Test Topic */
			model.getTopic().setSubject("biology");
			model.getTopic().setSubjectYear(50);
			
			myStmt = myConn.prepareStatement("SELECT * FROM " + model.getTopic().getSubject().toLowerCase() + " WHERE topicYear =?");
			myStmt.setInt(1, model.getTopic().getSubjectYear());
			myRs = myStmt.executeQuery(); 
			myRs.next();
			assertEquals("This string should be 'Test Topic Content1�Test Topic Content2�Test Topic Content3'", 
					"Test Topic Content1�Test Topic Content2�Test Topic Content3",
					myRs.getString("TopicContents"));
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
