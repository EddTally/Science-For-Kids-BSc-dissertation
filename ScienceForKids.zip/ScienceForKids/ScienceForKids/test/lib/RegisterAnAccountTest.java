package lib;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.junit.Test;
import org.mindrot.jbcrypt.BCrypt;

import model.User;
import model.ScienceForKidsProfile;


public class RegisterAnAccountTest {
	private ScienceForKidsProfile model;	
	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;

	/* -- START OF UNIT TESTS -- */

	@Test
	public void testRegisteringAnAccount() {
		model = new ScienceForKidsProfile();
		new User();
		
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
		
		/* Testing a password mismatch from the password stored in the model to a normal string. */
		model.getUser().setPassword("password");
		String passwordCheck = "passwordWrong";
		
		assertFalse(model.getUser().getPassword().equals(passwordCheck)); 
		

		/* Testing for a username that already exists in the system*/
		model.getUser().setUsername("realUsername");
		try {
			myStmt = myConn.prepareStatement("SELECT username FROM user WHERE username =? ");
			myStmt.setString(1, model.getUser().getUsername());
			myRs = myStmt.executeQuery();
			myRs.next();
			assertEquals("The username in the database should equal the username in the model", model.getUser().getUsername(), myRs.getString("username"));				

			/* Testing for a username that doesn't exists in the system and the hashing password*/
			model.getUser().setUsername("nonExistingUsername");
			model.getUser().setPassword("nonExistantPassword");
			//Hashing password
			String hashed = BCrypt.hashpw(model.getUser().getPassword(), BCrypt.gensalt(12));
			assertTrue(BCrypt.checkpw(model.getUser().getPassword(), hashed));
				
			/* This test can only be run once before having to delete user from database */
			myStmt = myConn.prepareStatement("INSERT INTO user(username, password, totalMarks, topicsCompleted) VALUES(?, ?, ?, ?)");
			myStmt.setString(1, model.getUser().getUsername());
			myStmt.setString(2, hashed);
			myStmt.setInt(3, model.getUser().getTotalMarks());
			myStmt.setString(4, model.getUser().getTopicsCompleted());
			myStmt.executeUpdate();
				
			/* Testing for the username that just got entered into the system */
			myStmt = myConn.prepareStatement("SELECT * FROM user WHERE username =? ");
			myStmt.setString(1, model.getUser().getUsername());
			myRs = myStmt.executeQuery();
			myRs.next();
			assertEquals("The username in the database should equal the username in the model", model.getUser().getUsername(), myRs.getString("username"));			

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if (myRs != null) {
				try {
					myRs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (myStmt != null) {
				try {
					myStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
			
	}
		
}
