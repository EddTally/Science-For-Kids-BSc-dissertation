package lib;

import static org.junit.Assert.*;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import model.Question;
import model.Questionnaire;
import model.ScienceForKidsProfile;
import model.User;

public class MarkingQuiz {

	private ScienceForKidsProfile model;	
	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;

	@Test
	public void MarkingQuizTest() {
		model = new ScienceForKidsProfile();
		new User();

		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

		}
		catch (Exception exc) {
			exc.printStackTrace();
		}

		try {
			
			
			model.getTopic().setSubject("biology");
			model.getTopic().setSubjectYear(50);
			model.getTopic().setTopicName("Test Topic Biology");
			model.getTopic().setTopicId(100);
			/* Getting Example Questions from the database */
			myStmt = myConn.prepareStatement("SELECT * FROM " +model.getTopic().getSubject() + "questions WHERE "
					+ model.getTopic().getSubject() + "_" + "id"+model.getTopic().getSubject().toLowerCase() + " =? ");
			myStmt.setInt(1, model.getTopic().getTopicId());
			myRs = myStmt.executeQuery();
			myRs.next();
				// POPULATING QUESTIONNAIRE
				Questionnaire exampleQuestionnaire = new Questionnaire();
				Question Question1 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"), null);
				myRs.next();
				Question Question2 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"), null);
				myRs.next();
				Question Question3 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"), null);


				exampleQuestionnaire.addQuestion(Question1);
				exampleQuestionnaire.addQuestion(Question2);
				exampleQuestionnaire.addQuestion(Question3);

				model.setQuestionnaire(exampleQuestionnaire);
				
				/* Pre-written answers */
				String correctAnswer = "answer";
				String wrongAnswer = "wrongAnswer";
				int wrongCount = 0;
				
				/* Comparing example Questions with pre-written questionnaire */
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionAnswer(), correctAnswer);	
				model.setTotalMark(1);
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(1).getQuestionAnswer(), correctAnswer);	
				model.setTotalMark(1);
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionAnswer(), correctAnswer);	
				model.setTotalMark(1);				
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionAnswer(), correctAnswer);	
				model.setTotalMark(1);
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionAnswer(), correctAnswer);	
				model.setTotalMark(1);
				
				assertNotEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionAnswer(), wrongAnswer);
				wrongCount += 1;
				assertNotEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(1).getQuestionAnswer(), wrongAnswer);
				wrongCount += 1;
				assertNotEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionAnswer(), wrongAnswer);
				wrongCount += 1;
				
				assertEquals(model.getTotalMark(), 5);
				assertEquals(wrongCount, 3);
				
				System.out.println("Total Mark: " + model.getTotalMark());
				System.out.println("Wrong Counter: " + wrongCount);
				
				
		}catch(SQLException e) {
			e.printStackTrace();
		}
		

	}

}
