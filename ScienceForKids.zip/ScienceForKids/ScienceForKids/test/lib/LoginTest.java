package lib;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.junit.Test;
import org.mindrot.jbcrypt.BCrypt;


import model.User;
import model.ScienceForKidsProfile;


public class LoginTest {
	private ScienceForKidsProfile model;
	
	
	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;
	/* -- START OF UNIT TESTS -- */

	@Test
	public void testLoginFunction() {

	model = new ScienceForKidsProfile();
	
	try {
		// 1. Get a connection to database
		myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

	}
	catch (Exception exc) {
		exc.printStackTrace();
	}
		
		try {
			/* First testing for the not existing username in the database*/
			model.getUser().setUsername("fakeUsername");
			
			myStmt = myConn.prepareStatement("SELECT * FROM user WHERE username =?");
			myStmt.setString(1, model.getUser().getUsername());
			myRs = myStmt.executeQuery(); 
			assertEquals("The results set should return false", false, myRs.next());

			
			/* Second testing for a real username in the database*/
			model.getUser().setUsername("realUsername");
			model.getUser().setPassword("realPassword");
			
			myStmt = myConn.prepareStatement("SELECT * FROM user WHERE username =?");
			myStmt.setString(1, model.getUser().getUsername());
			myRs = myStmt.executeQuery(); 
			
			if(myRs.next()){
				assertEquals("The Username should return realUsername", "realUsername", myRs.getString("username"));
				//If username has been found, Check that an unencrypted password matches one that has
				// previously been hashed
				assertTrue(BCrypt.checkpw(model.getUser().getPassword(), myRs.getString("password")));

				model.setUser(new User(myRs.getInt("iduser"), model.getUser().getUsername(), model.getUser().getPassword(), 
						myRs.getInt("totalMarks"), myRs.getString("topicsCompleted")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if (myRs != null) {
				try {
					myRs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (myStmt != null) {
				try {
					myStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		assertEquals("Id field should be the same as the id for the user in the database", 44, model.getUser().getUserId());
		assertEquals("Username field should contain", "realUsername", model.getUser().getUsername());
		assertEquals("TotalMarks field should contain 0", 0, model.getUser().getTotalMarks());
		assertEquals("topicsCompleted field should contain an empty string", "", model.getUser().getTopicsCompleted());

	}


}
