package lib;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import javafx.scene.image.Image;
import model.Question;
import model.Questionnaire;
import model.ScienceForKidsProfile;
import model.User;

public class TakingQuiz {

	private ScienceForKidsProfile model;	
	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;
	private byte byteImage[];
	private Blob blob;

	@Test
	public void TakingYoungerQuizTest() {
		model = new ScienceForKidsProfile();
		new User();

		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

		}
		catch (Exception exc) {
			exc.printStackTrace();
		}

		try {
			
			
			model.getTopic().setSubject("biology");
			model.getTopic().setSubjectYear(50);
			model.getTopic().setTopicName("Test Topic Biology");
			model.getTopic().setTopicId(100);
			/* Getting Example Questions from the database */
			myStmt = myConn.prepareStatement("SELECT * FROM " +model.getTopic().getSubject() + "questions WHERE "
					+ model.getTopic().getSubject() + "_" + "id"+model.getTopic().getSubject().toLowerCase() + " =? ");
			myStmt.setInt(1, model.getTopic().getTopicId());
			myRs = myStmt.executeQuery();
			myRs.next();
				// POPULATING QUESTIONNAIRE
				Questionnaire exampleQuestionnaire = new Questionnaire();
				Question Question1 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
						convertBlobToImage(blob = myRs.getBlob("questionImg")));
				myRs.next();
				Question Question2 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
						convertBlobToImage(blob = myRs.getBlob("questionImg")));
				myRs.next();
				Question Question3 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
						myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
						convertBlobToImage(blob = myRs.getBlob("questionImg")));


				exampleQuestionnaire.addQuestion(Question1);
				exampleQuestionnaire.addQuestion(Question2);
				exampleQuestionnaire.addQuestion(Question3);

				model.setQuestionnaire(exampleQuestionnaire);
				
				/* Pre-written Questionnaire */
				Questionnaire preQuestionnaire = new Questionnaire();
				preQuestionnaire.addQuestion(new Question(1, "Example question 1", "answer", "answer1�answer2�answer3", false, null));
				preQuestionnaire.addQuestion(new Question(2, "Example question 2", "answer", "answer1�answer2�answer3", false, null));
				preQuestionnaire.addQuestion(new Question(3, "Example question 3", "answer", "answer1�answer2�answer3", false, null));
				
				/* Comparing example Questions with pre-written questionnaire */
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(0).toString(), 
						preQuestionnaire.getQuestionByQuestionNumber(0).toString());
				assertNotNull(model.getQuestionnnaire().getQuestionByQuestionNumber(0));
				
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(1).toString(), 
						preQuestionnaire.getQuestionByQuestionNumber(1).toString());
				assertNotNull(model.getQuestionnnaire().getQuestionByQuestionNumber(1));
				
				assertEquals(model.getQuestionnnaire().getQuestionByQuestionNumber(2).toString(), 
						preQuestionnaire.getQuestionByQuestionNumber(2).toString());
				assertNotNull(model.getQuestionnnaire().getQuestionByQuestionNumber(2));
				
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
	}
		// Coverting Blob to Image function
		private Image convertBlobToImage(Blob blob) {
			try {
				if(blob == null) {
					return null;
				}else {
					byteImage = blob.getBytes(1,(int)blob.length());
				}
			} catch (SQLException e) {
				System.out.println("converyBlobToImage not working");
				e.printStackTrace();
			}
			return new Image(new ByteArrayInputStream(byteImage)); 
		}

	}
