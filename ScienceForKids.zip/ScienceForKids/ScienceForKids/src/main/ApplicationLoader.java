package main;


import view.ScienceForKidsRootPane;
import model.ScienceForKidsProfile;

import java.sql.SQLException;

import controller.ScienceForKidsController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ApplicationLoader extends Application {
	
	private ScienceForKidsRootPane view;
	private ScienceForKidsProfile model;
	
	@Override
	public void init() throws SQLException {
		
		//create model and view and pass their references to the controller	
		view = new ScienceForKidsRootPane();
		model = new ScienceForKidsProfile();
		new ScienceForKidsController(view, model);	
	}
	
	
	@Override
	public void start(Stage stage) throws Exception {
		stage.setTitle("Science For Kids");
		Scene scene = new Scene(view, 1500, 700); //Extending Borderpane in scienceforkidsrootpane fixes parent issue
		scene.getStylesheets().add("StyleSheet.css");
		stage.setScene(scene);
		
		stage.show();
	}
	

	public static void main(String[] args){		
		launch(args);	
	}







	

}
