package controller;

import java.sql.*;

import org.mindrot.jbcrypt.BCrypt;

import java.io.ByteArrayInputStream;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import model.Question;
import model.Questionnaire;
import model.ScienceForKidsProfile;
import model.Topic;
import model.User;
import view.ChoosingSubjectPane;
import view.ChoosingTopicPane;
import view.LearningScreenPane;
import view.LevelOfStudyPane;
import view.LoginScreenPane;
import view.MainScreenPane;
import view.OlderQuizPane;
import view.ScienceForKidsRootPane;
import view.YoungerQuizPane;

public class ScienceForKidsController {

	private MainScreenPane msP;
	private LoginScreenPane loginP;
	private LevelOfStudyPane losP;
	private ChoosingSubjectPane csP;
	private ChoosingTopicPane ctP;
	private LearningScreenPane learnP;
	private YoungerQuizPane yqP;
	private OlderQuizPane oqP;
	private ScienceForKidsRootPane view;
	private ScienceForKidsProfile model;

	private Connection myConn = null;
	private PreparedStatement myStmt = null;
	private ResultSet myRs = null;
	private byte byteImage[];
	private Blob blob;
	private ObservableList<String> listViewItems = FXCollections.observableArrayList();

	public ScienceForKidsController(ScienceForKidsRootPane view, ScienceForKidsProfile model) throws SQLException{

		this.view = view;
		this.model = model;

		msP = view.getMainScreenPane();
		loginP = view.getLoginScreenPane();
		losP = view.getLevelOfStudyPane();
		csP = view.getChoosingSubjectPane();
		ctP = view.getChoosingTopicPane();
		learnP = view.getLearningScreenPane();
		yqP = view.getYoungerQuizPane();
		oqP = view.getOlderQuizPane();

		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/scienceforkids?useSSL=false", "root" , "root1");

		}
		catch (Exception exc) {
			exc.printStackTrace();
		}


		this.attachEventHandlers();
	}


	private void attachEventHandlers() {
		msP.addCreateUserEventHandler(new createUserEventHandler());
		msP.addGuestEventHandler(new guestEventHandler());
		msP.addMainScreenLoginEventHandler(new mainScreenLoginEventHandler());

		loginP.addDefaultLoginEventHandler(new defaultLoginEventHandler());
		loginP.addGoBackEventHandler(new loginScreenGoBackEventHandler());

		losP.addLogoutEventHandler(new logoutEventHandler());
		losP.addYear4EventHandler(new year4EventHandler());
		losP.addYear5EventHandler(new year5EventHandler());
		losP.addYear6EventHandler(new year6EventHandler());
		losP.addYear7EventHandler(new year7EventHandler());

		csP.addBiologyEventHandler(new biologyEventHandler());
		csP.addChemistryEventHandler(new chemistryEventHandler());
		csP.addGoBackEventHandler(new choosingSubjectGoBackEventHandler());
		csP.addPhysicsEventHandler(new physicsEventHandler());
		csP.addLogoutBtnEventHandler(new logoutEventHandler());

		ctP.addTopicChosenEventHandler(new topicChosenEventHandler());
		ctP.addGoBackBtnEventHandler(new choosingTopicGoBackEventHandler());
		ctP.addLogoutEventHandler(new logoutEventHandler());

		learnP.addLearningScreenGoBackEventHandler(new learningScreenGoBackEventHandler());
		learnP.addTakeQuizEventHandler(new takeQuizEventHandler());
		learnP.addLogoutBtnEventHandler(new logoutEventHandler());
		learnP.addNextContentBtnEventHandler(new nextContentButtonEventHandler());


		yqP.addAnswer1BtnEventHander(new answer1BtnEventHandler());
		yqP.addAnswer2BtnEventHander(new answer2BtnEventHandler());
		yqP.addAnswer3BtnEventHander(new answer3BtnEventHandler());
		yqP.addBackToTopicsBtnEventHandler(new backToTopicsEventHandler());

		oqP.addBackToTopicsBtnEventHandler(new backToTopicsEventHandler());
		oqP.addMarkQuestionnaireBtnEventHandler(new markQuestionnaireBtnEventHandler());
	}

	/***************************************** Main Screen Pane Event Handlers*******************************************/
	private class createUserEventHandler implements EventHandler<ActionEvent>{
		public void handle(ActionEvent event) {
			/* First Checks that the passwords both match.
			 * IF TRUE THEN
			 * Sets up new user in model to store username and password inputed into textfields.
			 * creates a new statement to select all usernames from user table in db where the USERNAME = INPUT
			 * IF the ResultsSet object has a .next() this means there is already 1 in the database.
			 * this is to see if user already exists before inserting.
			 * If it does exist an alert box is created, x = 1 which stops the other function for executing.
			 * If it doesn't then we Hash the new password 
			 * THEN
			 * Prepare a new statement and executeUpdate.
			 * after that is a check to see if it has entered the database, this will be deleted later
			 */
			// Couldn't find a better way to stop further execution of this class than x=0

			if(!msP.getNewPassword().equals(msP.getPasswordCheck())) {
				simpleAlert(AlertType.WARNING, "Password mismatch", "Your passwords do not match", "");
				System.out.println(msP.getNewPassword() + msP.getPasswordCheck());
				return;
			}

			int x = 0;
			model.setUser(new User(0, msP.getNewUsername(), msP.getNewPassword(), 0, ""));

			try {
				myStmt = myConn.prepareStatement("SELECT username FROM user WHERE username =? ");
				myStmt.setString(1, model.getUser().getUsername());
				myRs = myStmt.executeQuery();
				if(myRs.next()) {
					simpleAlert(AlertType.WARNING, "Register Error", "This username already exists please try another", "");
					System.out.println("User already exists");
					x = 1;
				}				

				if(x == 0) {
					//Hashing password
					String hashed = BCrypt.hashpw(msP.getNewPassword(), BCrypt.gensalt(12));
					System.out.println(hashed);
					// 2. Create a statement
					myStmt = myConn.prepareStatement("INSERT INTO user(username, password, totalMarks, topicsCompleted) VALUES(?, ?, ?, ?)");
					myStmt.setString(1, model.getUser().getUsername());
					myStmt.setString(2, hashed);
					myStmt.setInt(3, model.getUser().getTotalMarks());
					myStmt.setString(4, model.getUser().getTopicsCompleted());
					myStmt.executeUpdate();

					// Changing View after successful registering
					view.setPane(loginP);

					System.out.println("Insert Complete");

					// 4. Check if added name
					myRs = myStmt.executeQuery("select * from user");
					// 4. Process the result set
					while (myRs.next()) {
						System.out.println("Username: " + myRs.getString("username") + ", Password: " + myRs.getString("password") + ","
								+ " Total Marks: " + myRs.getInt("totalMarks") + ", Topics Completed: " + myRs.getString("topicsCompleted"));
					}
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				if (myRs != null) {
					try {
						myRs.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (myStmt != null) {
					try {
						myStmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	private class guestEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			view.setPane(losP);

		}
	}

	private class mainScreenLoginEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			view.setPane(loginP);
		}
	}






	/************************************ Login Screen Pane Event Handlers ***************************************/
	private class defaultLoginEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {

			try {
				myStmt = myConn.prepareStatement("SELECT * FROM user WHERE username =?");
				myStmt.setString(1, loginP.getUsername());
				myRs = myStmt.executeQuery(); 
				if(myRs.next()){
					//If username has been found, Check that an unencrypted password matches one that has
					// previously been hashed
					if (BCrypt.checkpw(loginP.getPassword(), myRs.getString("password"))) {
						System.out.println("It matches");
					}else {
						simpleAlert(AlertType.WARNING, "Login Error", "Your Login Details are incorrect", "Your password "
								+ "does not match the one stored in the database for this user");
						System.out.println("Your password does not match the one stored in the database for this user");
						return;
					}

					losP.setUsernameLabel(("Welcome " + model.getUser().getUsername()));
					model.setUser(new User(myRs.getInt("iduser"), loginP.getUsername(), loginP.getPassword(), 
							myRs.getInt("totalMarks"), myRs.getString("topicsCompleted")));
					System.out.println(model.getUser().toString());
					view.setPane(losP);
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				if (myRs != null) {
					try {
						myRs.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (myStmt != null) {
					try {
						myStmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	/* This event Handler is a default for all panes <- NO*/
	private class loginScreenGoBackEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			view.setPane(msP);

		}
	}







	/************************************ Level Of Study Pane Event Handlers ************************************/
	private class year4EventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubjectYear(4);
			view.setPane(csP);
			csP.setStudyYear(model.getTopic().getSubjectYear());		}
	}

	private class year5EventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubjectYear(5);
			view.setPane(csP);
			csP.setStudyYear(model.getTopic().getSubjectYear());		}
	}

	private class year6EventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubjectYear(6);
			view.setPane(csP);
			csP.setStudyYear(model.getTopic().getSubjectYear());		}
	}

	private class year7EventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubjectYear(7);
			view.setPane(csP);
			csP.setStudyYear(model.getTopic().getSubjectYear());		}
	}






	/************************************ Choosing Subject Pane Event Handlers ************************************/
	private class physicsEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubject("Physics");
			choosingSubjectEventHandlerCode();		
			ctP.getTopicListView().setItems(listViewItems);	
			view.setPane(ctP);
			ctP.setSubjectAndStudyYearChosenLbl(model.getTopic().getSubjectYear(), model.getTopic().getSubject());
		}
	}

	private class biologyEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubject("Biology");
			choosingSubjectEventHandlerCode();
			ctP.getTopicListView().setItems(listViewItems);	
			view.setPane(ctP);
			ctP.setSubjectAndStudyYearChosenLbl(model.getTopic().getSubjectYear(), model.getTopic().getSubject());	
		}
	}

	private class chemistryEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			model.getTopic().setSubject("Chemistry");
			choosingSubjectEventHandlerCode();
			ctP.getTopicListView().setItems(listViewItems);			
			view.setPane(ctP);
			ctP.setSubjectAndStudyYearChosenLbl(model.getTopic().getSubjectYear(), model.getTopic().getSubject());

		}
	}

	/* This event handler is a go back button on the Choosing Subject Pane to go back to the Level Of Study Pane */
	private class choosingSubjectGoBackEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			view.setPane(losP);

		}
	}

	private void choosingSubjectEventHandlerCode() {

		try {
			myStmt = myConn.prepareStatement("SELECT * FROM " + model.getTopic().getSubject().toLowerCase() + " WHERE topicYear =?");
			myStmt.setInt(1, model.getTopic().getSubjectYear());
			myRs = myStmt.executeQuery(); 
			while(myRs.next()){
				System.out.println(myRs.getString("topicName"));
				listViewItems.add(myRs.getString("topicName")); 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}





	/************************************ Choosing Topic Pane Event Handlers ************************************/
	private class topicChosenEventHandler implements EventHandler<MouseEvent> {
		public void handle(MouseEvent event) {
			if(event.getClickCount() == 1) {
				model.getTopic().setTopicName(ctP.getTopicChosen());
				learnP.setTopicTitle(model.getTopic().getTopicName());
			}
			// This if function stops double clicking on list view triggering the change of view
			if(model.getTopic().getTopicName() != null) {

				// Loading Topic Content into text area
				try {
					myStmt = myConn.prepareStatement("SELECT * FROM " + model.getTopic().getSubject().toLowerCase() + " WHERE topicName =?");
					myStmt.setString(1, model.getTopic().getTopicName());
					myRs = myStmt.executeQuery(); 
					if(myRs.next()){
						model.getTopic().setTopicContents(myRs.getString("topicContents")); 
						//Setting Topic Id
						model.getTopic().setTopicId(myRs.getInt("id"+model.getTopic().getSubject().toLowerCase()));
						System.out.println(model.getTopic().getTopicId());
						/* https://stackoverflow.com/questions/44157955/retrieve-image-from-db-and-display-them-into-javafx */
						learnP.setImageView(convertBlobToImage(blob = myRs.getBlob("topicImg")));

					}else {
						System.out.println("No Topic Content Found");
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}

				/* Setting up topicContents in splitString format */
				model.getTopic().setSplitTopicContents(splitTopicContents(model.getTopic().getTopicContents()));
				learnP.setTopicMaterial(model.getTopic().getSplitTopicContents()[model.getTopic().getTopicSplitDisplayCount()]);
				model.getTopic().setTopicSplitDisplayCount(1);


				view.setPane(learnP);

			}
		}
	}
	private class choosingTopicGoBackEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			ctP.getTopicListView().getItems().clear();
			view.setPane(csP);

		}
	}





	/************************************ Learning Screen Pane Event Handlers ************************************/

	private class nextContentButtonEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			/* If the number of pages in the topic is more than the number of pages that have been displayed
			 * display the next topic, else print "All Content has been displayed and enable the test button"
			 */
			if(model.getTopic().getTopicSplitNumber() > model.getTopic().getTopicSplitDisplayCount()) {
				learnP.setTopicMaterial(model.getTopic().getSplitTopicContents()[model.getTopic().getTopicSplitDisplayCount()]);
				model.getTopic().setTopicSplitDisplayCount(model.getTopic().getTopicSplitDisplayCount() + 1);
			}
			if(model.getTopic().getTopicSplitNumber() == model.getTopic().getTopicSplitDisplayCount()) {
				System.out.println("All Content has been displayed");
				learnP.getNextContentBtn().setDisable(true);
				learnP.getTakeQuizBtn().setDisable(false);
			}
		}
	}

	private class learningScreenGoBackEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			// Resetting the topic chosen stuff and setting subject chosen again
			String subject = model.getTopic().getSubject();
			int subjectYear = model.getTopic().getSubjectYear();
			model.setTopic(new Topic());
			model.getTopic().setSubject(subject);
			model.getTopic().setSubjectYear(subjectYear);

			// Resetting buttons on learning content screen
			learnP.getNextContentBtn().setDisable(false);
			learnP.getTakeQuizBtn().setDisable(true);


			view.setPane(ctP);
		}
	}

	private String[] splitTopicContents(String topicContents) {
		// Starts at 1 because � is only used to seperate content, therefore there will always be 1 less �
		// then there is split strings
		int x = 1;
		for(int i = 0; i < topicContents.length(); i++) {
			if(topicContents.charAt(i) == '�') {
				x++;
			}
		}
		model.getTopic().setTopicSplitNumber(x);
		String[] parts = topicContents.split("�", x);
		return parts;

	}

	private class takeQuizEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {

			int x = model.getTopic().getSubjectYear();


			/******************** Younger Quiz ******************/
			if(x == 4 || x == 5) {

				//Selecting correct questions to load into database
				try {
					myStmt = myConn.prepareStatement("SELECT * FROM " +model.getTopic().getSubject() + "questions WHERE "
							+ model.getTopic().getSubject() + "_" + "id"+model.getTopic().getSubject().toLowerCase() + " =? ");
					myStmt.setInt(1, model.getTopic().getTopicId());
					myRs = myStmt.executeQuery();
					if(myRs.next()) {
						// POPULATING QUESTIONNAIRE
						Questionnaire yQuestionnaire = new Questionnaire();
						Question yQuestion1 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion2 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion3 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion4 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion5 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion6 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion7 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question yQuestion8 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));

						yQuestionnaire.addQuestion(yQuestion1);
						yQuestionnaire.addQuestion(yQuestion2);
						yQuestionnaire.addQuestion(yQuestion3);
						yQuestionnaire.addQuestion(yQuestion4);
						yQuestionnaire.addQuestion(yQuestion5);
						yQuestionnaire.addQuestion(yQuestion6);
						yQuestionnaire.addQuestion(yQuestion7);
						yQuestionnaire.addQuestion(yQuestion8);

						model.setQuestionnaire(yQuestionnaire);

					}
				}catch(SQLException e) {
					e.printStackTrace();
				}

				//Finally setting up Question Text, Button and Image
				yqP.setQuestionText(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionText());
				setYoungerAnswerBtnAnswers(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getMultipleChoiceAnswers());
				yqP.getImageView().setImage(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionImage());

				yqP.setQuestionNumberLbl("Question: ", 1);

				// Increasing Question Number by 1 after loading for the next question to be BLAH BLAH
				model.getQuestion().setQuestionNumber(0);

				view.setPane(yqP);




				/****************** Older Quiz **********************/
			}else if(x == 6 || x == 7) {

				//Selecting correct questions to load into database
				try {
					myStmt = myConn.prepareStatement("SELECT * FROM " +model.getTopic().getSubject() + "questions WHERE "
							+ model.getTopic().getSubject() + "_" + "id"+model.getTopic().getSubject().toLowerCase() + " =? ");
					myStmt.setInt(1, model.getTopic().getTopicId());
					myRs = myStmt.executeQuery();
					if(myRs.next()) {
						// POPULATING QUESTIONNAIRE
						Questionnaire oQuestionnaire = new Questionnaire();
						Question oQuestion1 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question oQuestion2 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question oQuestion3 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question oQuestion4 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));
						myRs.next();
						Question oQuestion5 = new Question(myRs.getInt("questionNumber"), myRs.getString("questionText"), 
								myRs.getString("questionAnswer"), myRs.getString("multipleChoiceAnswers"), myRs.getBoolean("questionAttempted"),
								convertBlobToImage(blob = myRs.getBlob("questionImg")));

						oQuestionnaire.addQuestion(oQuestion1);
						oQuestionnaire.addQuestion(oQuestion2);
						oQuestionnaire.addQuestion(oQuestion3);
						oQuestionnaire.addQuestion(oQuestion4);
						oQuestionnaire.addQuestion(oQuestion5);

						model.setQuestionnaire(oQuestionnaire);

					}
				}catch(SQLException e) {
					e.printStackTrace();
				}
				// Setting up Question Text
				oqP.setQuestionLabels("1. " + model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionText(),
						"2. " + model.getQuestionnnaire().getQuestionByQuestionNumber(1).getQuestionText(),
						"3. " + model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionText(),
						"4. " + model.getQuestionnnaire().getQuestionByQuestionNumber(3).getQuestionText(),
						"5. " + model.getQuestionnnaire().getQuestionByQuestionNumber(4).getQuestionText());
				System.out.println(model.getQuestionnnaire().toString());

				// Setting up answer combo boxes for Questionnaire
				setOlderAnswerCmbAnswers(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getMultipleChoiceAnswers(),
						model.getQuestionnnaire().getQuestionByQuestionNumber(1).getMultipleChoiceAnswers(), 
						model.getQuestionnnaire().getQuestionByQuestionNumber(2).getMultipleChoiceAnswers(),
						model.getQuestionnnaire().getQuestionByQuestionNumber(3).getMultipleChoiceAnswers(),
						model.getQuestionnnaire().getQuestionByQuestionNumber(4).getMultipleChoiceAnswers());

				// Setting up Question Images
				oqP.setImageView1(model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionImage());
				oqP.setImageView2(model.getQuestionnnaire().getQuestionByQuestionNumber(1).getQuestionImage());
				oqP.setImageView3(model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionImage());
				oqP.setImageView4(model.getQuestionnnaire().getQuestionByQuestionNumber(3).getQuestionImage());
				oqP.setImageView5(model.getQuestionnnaire().getQuestionByQuestionNumber(4).getQuestionImage());

				view.setPane(oqP);
			}			
		}
	}





	/************************************ Younger Quiz Pane Event Handlers ************************************/
	private class answer1BtnEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {			
			checkYoungerQuizAnswers(yqP.getAnswer1Btn());
		}
	}

	private class answer2BtnEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			checkYoungerQuizAnswers(yqP.getAnswer2Btn());
		}
	}

	private class answer3BtnEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {
			checkYoungerQuizAnswers(yqP.getAnswer3Btn());
		}
	}
	/* Creating seperate function to reuse for buttons to save code */
	private void checkYoungerQuizAnswers(Button btn) {

		/* IF answer is correct, set relevant labels background green,
		 * update total mark in model 
		 * IF question number is 10 Alert Box Popup
		 * ELSE
		 * Background for relevant questionLabel turns red and question numbers are updated
		 * THEN
		 * set the questionNumber of the model,
		 * update the questionNumber label in YougerQuizPane to the same at the models
		 * THEN
		 * load in the next button answers and Question Text
		 * 
		 * This is the same for all Answer Button Event Handlers
		 */

		if(btn.getText().equals(model.getQuestionnnaire().getQuestionByQuestionNumber(
				model.getQuestion().getQuestionNumber()).getQuestionAnswer())) {// +1 Selects correct label background to change
			yqP.getFlowPane().getChildren().get((model.getQuestion().getQuestionNumber() + 1)).setStyle("-fx-background-color:green;");	
			model.setTotalMark(1);
			model.getQuestion().setQuestionNumber((model.getQuestion().getQuestionNumber() + 1));

		}else {
			yqP.getFlowPane().getChildren().get(model.getQuestion().getQuestionNumber() + 1).setStyle("-fx-background-color:red;");
			model.getQuestion().setQuestionNumber((model.getQuestion().getQuestionNumber() + 1));
		}
		//When user has completed Questionnaire this alert box will popup
		if(model.getQuestion().getQuestionNumber() == 8) {
			simpleAlert(AlertType.CONFIRMATION, "Test Completed", "Well done you have completed this Test",
					"Your Score was: " + model.getTotalMark());
			yqP.getAnswer1Btn().setDisable(true);
			yqP.getAnswer2Btn().setDisable(true);
			yqP.getAnswer3Btn().setDisable(true);

			//Updating topicsCompleted and totalMarks column in users table and within the model
			try {
				myStmt = myConn.prepareStatement("SELECT * FROM user WHERE iduser =?");
				myStmt.setInt(1, model.getUser().getUserId());
				myRs = myStmt.executeQuery();
				while(myRs.next()) {	// Positioning cursor on first row	
					if(myRs.getString("topicsCompleted").contains(model.getTopic().getTopicName())) {
						System.out.println("Topic already completed: " + model.getTopic().getTopicName());
					}else {
						System.out.println(model.getUser().getTopicsCompleted() + "\n" + model.getTopic().getTopicName());
						myStmt = myConn.prepareStatement("UPDATE user SET topicsCompleted=? WHERE iduser=?");
						myStmt.setString(1, model.getUser().getTopicsCompleted() + model.getTopic().getTopicName() + "-");
						myStmt.setInt(2, model.getUser().getUserId());
						myStmt.executeUpdate();
						model.getUser().setCompletedTopics(model.getUser().getTopicsCompleted() + model.getTopic().getTopicName() + "�");
					}
					myStmt = myConn.prepareStatement("UPDATE user SET totalMarks =? WHERE iduser=?");
					myStmt.setInt(1, model.getUser().getTotalMarks() + model.getTotalMark());
					myStmt.setInt(2, model.getUser().getUserId());
					myStmt.executeUpdate();
					model.getUser().setTotalMarks(model.getUser().getTotalMarks() + model.getTotalMark());
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}

		}else {	
			// + 1 Sets up the Label for the next question to be loaded in
			yqP.setQuestionNumberLbl("Question: ", model.getQuestion().getQuestionNumber() + 1);

			// Loading next answer buttons, question text and image
			yqP.setQuestionText(model.getQuestionnnaire().getQuestionByQuestionNumber(
					model.getQuestion().getQuestionNumber()).getQuestionText()); 
			setYoungerAnswerBtnAnswers(model.getQuestionnnaire().getQuestionByQuestionNumber(
					model.getQuestion().getQuestionNumber()).getMultipleChoiceAnswers());
			yqP.getImageView().setImage(model.getQuestionnnaire().getQuestionByQuestionNumber(
					model.getQuestion().getQuestionNumber()).getQuestionImage());

		}
	}


	/* Method to populate answer buttons for younger quiz pane */
	private void setYoungerAnswerBtnAnswers(String answers) {
		/* https://stackoverflow.com/questions/3481828/how-to-split-a-string-in-java 
		 * Splits String from database into 3 parts and assigns them to the buttons */
		if(answers.contains("�")) {
			String[] ans = answers.split("�", 3);

			yqP.getAnswer1Btn().setText(ans[0]);
			yqP.getAnswer2Btn().setText(ans[1]);
			yqP.getAnswer3Btn().setText(ans[2]);

		}else {
			throw new IllegalArgumentException("String " + answers + " does not contain �");
		}		
	}






	/************************************ Older Quiz Pane Event Handlers ************************************/
	private class markQuestionnaireBtnEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {

			// Making sure answers have been given for all questions
			if(oqP.getCombobox1().getSelectionModel().isEmpty() ||
					oqP.getCombobox2().getSelectionModel().isEmpty() ||
					oqP.getCombobox3().getSelectionModel().isEmpty() ||
					oqP.getCombobox4().getSelectionModel().isEmpty() ||
					oqP.getCombobox5().getSelectionModel().isEmpty()){
				simpleAlert(AlertType.WARNING, "Test not completed", "Please Attempt All Questions", "");
			}else {

				String Answer1 = model.getQuestionnnaire().getQuestionByQuestionNumber(0).getQuestionAnswer();
				String Answer2 = model.getQuestionnnaire().getQuestionByQuestionNumber(1).getQuestionAnswer();
				String Answer3 = model.getQuestionnnaire().getQuestionByQuestionNumber(2).getQuestionAnswer();
				String Answer4 = model.getQuestionnnaire().getQuestionByQuestionNumber(3).getQuestionAnswer();
				String Answer5 = model.getQuestionnnaire().getQuestionByQuestionNumber(4).getQuestionAnswer();

				if(oqP.getCombobox1().getSelectionModel().getSelectedItem().equals(Answer1)) {
					model.setTotalMark(1);
				}
				if(oqP.getCombobox2().getSelectionModel().getSelectedItem().equals(Answer2)) {
					model.setTotalMark(1);
				}
				if(oqP.getCombobox3().getSelectionModel().getSelectedItem().equals(Answer3)) {
					model.setTotalMark(1);
				}
				if(oqP.getCombobox4().getSelectionModel().getSelectedItem().equals(Answer4)) {
					model.setTotalMark(1);
				}
				if(oqP.getCombobox5().getSelectionModel().getSelectedItem().equals(Answer5)) {
					model.setTotalMark(1);
				}
				//When user has completed Questionnaire this alert box will popup
				simpleAlert(AlertType.CONFIRMATION, "Test Completed", "Well done you have completed this Test",
						"Your Score was: " + model.getTotalMark());
				oqP.getCombobox1().setDisable(true);
				oqP.getCombobox2().setDisable(true);
				oqP.getCombobox3().setDisable(true);
				oqP.getCombobox4().setDisable(true);
				oqP.getCombobox5().setDisable(true);
				oqP.getMarkQuestionnaireBtn().setDisable(true);
			}
		}
	}
	/* Method to populate combobox answers for older quiz pane */
	private void setOlderAnswerCmbAnswers(String a1, String a2, String a3, String a4, String a5) {
		/* https://stackoverflow.com/questions/3481828/how-to-split-a-string-in-java */
		if(a1.contains("�") && a2.contains("�") && a3.contains("�") && a4.contains("�") && a5.contains("�")) {


			// These for loops allow for a variable amount of answers to be loaded into the olderQuizPanes comboboxes
			int x = 1;
			for(int i = 0; i < a1.length(); i++) {
				if(a1.charAt(i) == '�') {
					x++;
				}
			}
			String[] answers1 = a1.split("�", x);
			for(int i = 0; i < x; i++) {
				oqP.getCombobox1().getItems().add(answers1[i]);
			}

			// Answer Combobox 2
			x = 1;
			for(int i = 0; i < a2.length(); i++) {
				if(a2.charAt(i) == '�') {
					x++;
				}
			}
			String[] answers2 = a2.split("�", x);
			for(int i = 0; i < x; i++) {
				oqP.getCombobox2().getItems().add(answers2[i]);
			}

			// Answer Combobox 3
			x = 1;
			for(int i = 0; i < a3.length(); i++) {
				if(a3.charAt(i) == '�') {
					x++;
				}
			}
			String[] answers3 = a3.split("�", x);
			for(int i = 0; i < x; i++) {
				oqP.getCombobox3().getItems().add(answers3[i]);
			}

			// Answer Combobox 4
			x = 1;
			for(int i = 0; i < a4.length(); i++) {
				if(a4.charAt(i) == '�') {
					x++;
				}
			}
			String[] answers4 = a4.split("�", x);
			for(int i = 0; i < x; i++) {
				oqP.getCombobox4().getItems().add(answers4[i]);
			}
			// Answer Combobox 5
			x = 1;
			for(int i = 0; i < a5.length(); i++) {
				if(a5.charAt(i) == '�') {
					x++;
				}
			}
			String[] answers5 = a5.split("�", x);
			for(int i = 0; i < x; i++) {
				oqP.getCombobox5().getItems().add(answers5[i]);
			}

		}else {
			throw new IllegalArgumentException("String " + a1 + a2 + a3 + a4 + a5 + " does not contain �");
		}		
	}



	/* This event Handler is the same for the 2 quiz panes*/
	private class backToTopicsEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {

			// resetting model questionnaire
			model.getQuestion().setQuestionNumber(0);
			model.resetTotalMark();
			model.setQuestion(new Question());
			model.setQuestionnaire(new Questionnaire());


			/* Resetting all style and model changes that have happened in quiz and creating a new pane*/
			ctP = new ChoosingTopicPane();
			ctP.setSubjectAndStudyYearChosenLbl(model.getTopic().getSubjectYear(), model.getTopic().getSubject());

			// Resetting the quiz panes to erase any previous changes
			yqP = new YoungerQuizPane();
			oqP = new OlderQuizPane();

			// Letting up the list view again, this stops duplication of topics
			ctP.getTopicListView().setItems(listViewItems);	

			// Resetting the topic chosen stuff and setting subject chosen again
			String subject = model.getTopic().getSubject();
			int subjectYear = model.getTopic().getSubjectYear();
			model.setTopic(new Topic());
			model.getTopic().setSubject(subject);
			model.getTopic().setSubjectYear(subjectYear);

			// Resetting buttons on learning content screen
			learnP.getNextContentBtn().setDisable(false);
			learnP.getTakeQuizBtn().setDisable(true);

			attachEventHandlers();

			view.setPane(ctP);

		}
	}
	/*************** This event Handler is the same for all panes ***************/
	private class logoutEventHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent event) {

			// Resetting model
			model.setUser(new User());
			model.setTopic(new Topic());
			model.setQuestion(new Question());
			model.setQuestionnaire(new Questionnaire());
			model.resetTotalMark();

			// Resetting View Panes
			ctP.getTopicListView().getItems().clear();
			msP.getNewUsernameField().clear();
			msP.getNewPasswordField().clear();
			msP.getPasswordCheckField().clear();

			loginP.getUsernameField().clear();
			loginP.getPasswordField().clear();

			view.setPane(msP);

		}
	}

	//helper method to build dialogs - use this during certain event handlers
	private void simpleAlert(AlertType type, String title, String header, String content) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.showAndWait();
	}

	// Coverting Blob to Image function
	private Image convertBlobToImage(Blob blob) {
		try {
			if(blob == null) {
				return null;
			}else {
				byteImage = blob.getBytes(1,(int)blob.length());
			}
		} catch (SQLException e) {
			System.out.println("converyBlobToImage not working");
			e.printStackTrace();
		}
		return new Image(new ByteArrayInputStream(byteImage)); 
	}

	/*// Alert Dialog for completion of test
	private void buttonAlert(Alert.AlertType alertType, String title, String header, String content, ButtonType... buttons) {
		Alert alert = new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);

		//buttons = new ButtonType("");


		for(ButtonType b : buttons) {
			b = new ButtonType("asdas");
		}

	}*/
}
