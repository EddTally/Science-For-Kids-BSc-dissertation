package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class LoginScreenPane extends BorderPane{
	
	private TextField username;
	private PasswordField password;
	private Button loginBtn, goBackBtn;

	
	
	public LoginScreenPane(){		
		GridPane gp = new GridPane();
		gp.setVgap(15);
		gp.setHgap(10);
		gp.setAlignment(Pos.CENTER);
		//gp.setGridLinesVisible(true);
		
		/* Science For Kids Title Label */
		Label title = new Label("Science for Kids");
		title.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		
		Label usernameLbl = new Label("Username: ");
		
		Label passwordLbl = new Label("Password: ");
		
		username = new TextField();
		username.setMaxWidth(150);
		username.setPromptText("username");
		
		password = new PasswordField();
		password.setMaxWidth(150);
		password.setPromptText("password");
	
		/* Login Button */
		loginBtn = new Button("Login");
		loginBtn.setPadding(new Insets(5, 10, 5, 10));
		loginBtn.setDefaultButton(true);
		
		
		/* Return to main Screen Pane Button*/
		goBackBtn = new Button("Go Back");
		goBackBtn.setPadding(new Insets(5, 10, 5, 10));		
		
		gp.add(usernameLbl, 0, 0);
		gp.add(passwordLbl, 0, 1);
		gp.add(username, 1, 0);
		gp.add(password, 1, 1);
		gp.add(loginBtn, 1, 2);		
		gp.add(goBackBtn, 0, 3, 1, 1);

		this.setPadding(new Insets(10, 10, 10, 10));
		this.setCenter(gp);
		this.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
	}


	public String getUsername(){
		return username.getText();
	}
	public TextField getUsernameField(){
		return username;
	}
	
	public String getPassword(){
		return password.getText();
	}
	public PasswordField getPasswordField(){
		return password;
	}
	
	public void addDefaultLoginEventHandler(EventHandler<ActionEvent> handler){
		loginBtn.setOnAction(handler);
	}
	
	public void addGoBackEventHandler(EventHandler<ActionEvent> handler){
		goBackBtn.setOnAction(handler);
	}

}
