package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class LearningScreenPane extends BorderPane {

	private TextArea topicMaterial;
	private Button goBackBtn, takeQuizBtn, logoutBtn, nextContentBtn;
	private Label topicChosen;
	private ImageView iv;
	
	public LearningScreenPane(){
		GridPane gp = addGridPane();
		
		topicChosen = new Label();
		topicChosen.setPadding(new Insets(30, 30, 30, 30));
		topicChosen.setFont(Font.font("Arial", 30));	
		
		this.setTop(topicChosen);
		this.setCenter(gp);
		this.setPadding(new Insets(10, 10, 10, 10));
		
	}
	
	public GridPane addGridPane() {
		GridPane gp = new GridPane();
		gp.setPadding(new Insets(10, 10, 10, 10));
		gp.setVgap(30);
		gp.setHgap(30);
		gp.setAlignment(Pos.CENTER);
		//gp.setGridLinesVisible(true);
		
		topicMaterial = new TextArea();
		topicMaterial.setPrefSize(600, 400);
		topicMaterial.setEditable(false);
		topicMaterial.setFont(Font.font("Arial", 25));
		topicMaterial.setWrapText(true);
		topicMaterial.setId("topicMaterial");
		
		iv = new ImageView();
		iv.setFitHeight(350);
		iv.setFitWidth(500);
		
		
		takeQuizBtn = new Button("Take Quiz");
		takeQuizBtn.setPadding(new Insets(10, 10, 10, 10));
		takeQuizBtn.setDisable(true);		
		
		goBackBtn = new Button("Back");
		goBackBtn.setPadding(new Insets(10, 10, 10, 10));
		
		logoutBtn = new Button("Logout");
		logoutBtn.setPadding(new Insets(10, 10, 10, 10));
		
		nextContentBtn = new Button("Next page");
		nextContentBtn.setPadding(new Insets(10, 10, 10, 10));
		
		gp.add(topicMaterial, 0, 0);
		gp.add(iv, 1, 0, 3, 1);
		gp.add(goBackBtn, 0, 1);
		gp.add(nextContentBtn, 1, 1);
		gp.add(takeQuizBtn, 2, 1);
		gp.add(logoutBtn, 3, 1);
				
		return gp;
	}
	
	public void setTopicTitle(String topicChosen){
		this.topicChosen.setText(topicChosen);
	}
	
	public TextArea getTopicMaterialObj(){
		return topicMaterial;
	}
	
	public void setTopicMaterial(String topicMaterial){
		this.topicMaterial.setText(topicMaterial);
	}
	
	public ImageView getImageView() {
		return iv;
	}
	public void setImageView(Image img) {
		iv.setImage(img);
	}
	public Button getTakeQuizBtn() {
		return takeQuizBtn;
	}
	public Button getNextContentBtn() {
		return nextContentBtn;
	}
	
	public void addLearningScreenGoBackEventHandler(EventHandler<ActionEvent> handler){
		goBackBtn.setOnAction(handler);
	}
	
	public void addTakeQuizEventHandler(EventHandler<ActionEvent> handler){
		takeQuizBtn.setOnAction(handler);
	}
	public void addNextContentBtnEventHandler(EventHandler<ActionEvent> handler){
		nextContentBtn.setOnAction(handler);
	}
	public void addLogoutBtnEventHandler(EventHandler<ActionEvent> handler){
		logoutBtn.setOnAction(handler);
	}
}
