package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class YoungerQuizPane extends BorderPane{

	private Label questionNumberLbl, q1, q2, q3, q4, q5, q6, q7, q8, questionText;
	private Button answer1Btn, answer2Btn, answer3Btn, backToTopicsBtn;
	private ImageView iv;
	private FlowPane fp;
	
	public YoungerQuizPane(){
		GridPane gp= addCenterGridPane();
		gp.setAlignment(Pos.CENTER);
		
		
		backToTopicsBtn = new Button("Back to Topic List");
		backToTopicsBtn.setPadding(new Insets(10, 10, 10, 10));

		this.setTop(backToTopicsBtn);
		this.setCenter(gp);
		this.setPadding(new Insets(10, 10, 10, 10));
	}
	
	public GridPane addCenterGridPane() {
		GridPane gp = new GridPane();
		gp.setPadding(new Insets(10, 10, 10, 10));
		gp.setVgap(20);
		gp.setHgap(15);
		gp.setAlignment(Pos.CENTER);
		gp.setMaxSize(1200, 800);
		//gp.setGridLinesVisible(true);
		
		
		iv = new ImageView();
		iv.setFitHeight(300);
		iv.setFitWidth(500);
		
		questionText = new Label("Question Text");
		questionText.setAlignment(Pos.CENTER);
		
		answer1Btn = new Button("Answer 1");
		answer1Btn.setPrefSize(800, 50);
		answer1Btn.getStyleClass().add("answerBtn");
		
		answer2Btn = new Button("Answer 2");
		answer2Btn.setPrefSize(800, 50);
		answer2Btn.getStyleClass().add("answerBtn");
		
		answer3Btn = new Button("Answer 3");
		answer3Btn.setPrefSize(800, 50);
		answer3Btn.getStyleClass().add("answerBtn");
		
		/* FlowPane for Running Marks Total */
		fp = new FlowPane(Orientation.VERTICAL);
		fp.setVgap(20);
		
		questionNumberLbl = new Label("questionNumber");
		
		q1 = new Label("Question 1");
		q2 = new Label("Question 2");
		q3 = new Label("Question 3");
		q4 = new Label("Question 4");
		q5 = new Label("Question 5");
		q6 = new Label("Question 6");
		q7 = new Label("Question 7");
		q8 = new Label("Question 8");

		fp.setAlignment(Pos.TOP_CENTER);
		fp.setId("answerFlowPane");
		
		fp.getChildren().addAll(questionNumberLbl, q1, q2, q3, q4, q5, q6, q7, q8);
		
		GridPane.setHalignment(questionText, HPos.CENTER);
		GridPane.setHalignment(iv, HPos.CENTER);
		gp.add(iv, 0, 0);
		gp.add(questionText, 0, 1);
		gp.add(answer1Btn, 0, 2);
		gp.add(answer2Btn, 0, 3);
		gp.add(answer3Btn, 0, 4);
		gp.add(fp, 1, 0, 1, 4);
		
		
		return gp;
	}
	
	
	public void setQuestionNumberLbl(String question, int questionNumber){
		this.questionNumberLbl.setText(question + questionNumber);
	} 
	
	public void setQuestionText(String questionText){
		this.questionText.setText(questionText);
	}
	
	public ImageView getImageView() {
		return iv;
	}
	public void setImageView(Image img) {
		iv.setImage(img);
	} 
	public FlowPane getFlowPane() {
		return fp;
	}
	public Button getAnswer1Btn() {
		return answer1Btn;
	}
	public Button getAnswer2Btn() {
		return answer2Btn;
	}
	public Button getAnswer3Btn() {
		return answer3Btn;
	}
	
	public void addAnswer1BtnEventHander(EventHandler<ActionEvent> handler){
		answer1Btn.setOnAction(handler);
	}
	public void addAnswer2BtnEventHander(EventHandler<ActionEvent> handler){
		answer2Btn.setOnAction(handler);
	}
	public void addAnswer3BtnEventHander(EventHandler<ActionEvent> handler){
		answer3Btn.setOnAction(handler);
	}
	
	public void addBackToTopicsBtnEventHandler(EventHandler<ActionEvent> handler){
		backToTopicsBtn.setOnAction(handler);
	}
	
}
