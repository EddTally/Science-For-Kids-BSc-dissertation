package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

public class OlderQuizPane extends BorderPane{

	private Label overallMark, question1Lbl, question2Lbl, question3Lbl, question4Lbl, question5Lbl;
	private Button markQuestionnaireBtn, backToTopicsBtn;
	private ComboBox<String> answer1Cmb, answer2Cmb, answer3Cmb, answer4Cmb, answer5Cmb;
	private ImageView iv1, iv2, iv3, iv4, iv5;


	public OlderQuizPane(){
		GridPane gp = addGridPane();
		gp.setAlignment(Pos.CENTER);

		backToTopicsBtn = new Button("Back to Topic List");
		backToTopicsBtn.setPadding(new Insets(10, 10, 10, 10));

		ScrollPane sp = new ScrollPane();
		sp.setContent(gp);
		sp.setFitToWidth(true);
		sp.setPadding(new Insets(10, 10, 10, 10));

		this.setCenter(sp);
		this.setTop(backToTopicsBtn);
		this.setPadding(new Insets(10, 10, 10, 10));


	}

	public GridPane addGridPane() {
		GridPane gp = new GridPane();
		//gp.setStyle("-fx-font: 20px \"Arial\";");
		gp.setMaxWidth(400);


		overallMark = new Label("Overall Mark /5");
		
		iv1 = new ImageView();

		iv2 = new ImageView();

		iv3 = new ImageView();

		iv4 = new ImageView();

		iv5 = new ImageView();


		question1Lbl = new Label("Question 1");
		question1Lbl.setWrapText(true);

		question2Lbl = new Label("Question 1");
		question2Lbl.setWrapText(true);

		question3Lbl = new Label("Question 1");
		question3Lbl.setWrapText(true);

		question4Lbl = new Label("Question 1");
		question4Lbl.setWrapText(true);

		question5Lbl = new Label("Question 1");
		question5Lbl.setWrapText(true);

		answer1Cmb = new ComboBox<String>();
		answer1Cmb.setPromptText("Select question 1 answer");
		answer1Cmb.setPrefSize(350, 50);

		answer2Cmb = new ComboBox<String>();
		answer2Cmb.setPromptText("Select question 2 answer");
		answer2Cmb.setPrefSize(350, 50);

		answer3Cmb = new ComboBox<String>();
		answer3Cmb.setPromptText("Select question 3 answer");
		answer3Cmb.setPrefSize(350, 50);

		answer4Cmb = new ComboBox<String>();
		answer4Cmb.setPromptText("Select question 4 answer");
		answer4Cmb.setPrefSize(350, 50);

		answer5Cmb = new ComboBox<String>();
		answer5Cmb.setPromptText("Select question 5 answer");
		answer5Cmb.setPrefSize(350, 50);

		markQuestionnaireBtn = new Button("Mark Questions");
		markQuestionnaireBtn.setPrefSize(250, 50);
		markQuestionnaireBtn.setPadding(new Insets(5, 5, 5, 5));
		markQuestionnaireBtn.setId("markQuestionBtn");
		GridPane.setHalignment(markQuestionnaireBtn, HPos.CENTER);
		

		// GridPane 1
		GridPane gp1 = new GridPane();
		gp1.setPadding(new Insets(10, 10, 10, 10));
		gp1.setHgap(15);
		gp1.setVgap(10);
		gp1.setAlignment(Pos.CENTER);
	
		gp1.add(iv1, 0, 0);
		gp1.add(question1Lbl, 0, 1);
		gp1.add(answer1Cmb, 0, 2);


		// GridPane 2
		GridPane gp2 = new GridPane();
		gp2.setPadding(new Insets(10, 10, 10, 10));
		gp2.setHgap(15);
		gp2.setVgap(10);
		gp2.setAlignment(Pos.CENTER);
		
		gp2.add(iv2, 0, 0);
		gp2.add(question2Lbl, 0, 1);
		gp2.add(answer2Cmb, 0, 2);

		// GridPane 3
		GridPane gp3 = new GridPane();
		gp3.setPadding(new Insets(10, 10, 10, 10));
		gp3.setHgap(15);
		gp3.setVgap(10);
		gp3.setAlignment(Pos.CENTER);

		gp3.add(iv3, 0, 0);
		gp3.add(question3Lbl, 0, 1);
		gp3.add(answer3Cmb, 0, 2);

		// GridPane 4
		GridPane gp4 = new GridPane();
		gp4.setPadding(new Insets(10, 10, 10, 10));
		gp4.setHgap(15);
		gp4.setVgap(10);
		gp4.setAlignment(Pos.CENTER);
		
		gp4.add(iv4, 0, 0);
		gp4.add(question4Lbl, 0, 1);
		gp4.add(answer4Cmb, 0, 2);

		// GridPane 5
		GridPane gp5 = new GridPane();
		gp5.setPadding(new Insets(10, 10, 10, 10));
		gp5.setHgap(15);
		gp5.setVgap(10);
		gp5.setAlignment(Pos.CENTER);
		
		gp5.add(iv5, 0, 0);
		gp5.add(question5Lbl, 0, 1);
		gp5.add(answer5Cmb, 0, 2);

		gp.add(gp1, 0, 0);
		gp.add(gp2, 0, 1);
		gp.add(gp3, 0, 2);
		gp.add(gp4, 0, 3);
		gp.add(gp5, 0, 4);

		gp.add(markQuestionnaireBtn, 0, 5);

		return gp;
	}

	public void setQuestionLabels(String q1, String q2, String q3, String q4, String q5){
		this.question1Lbl.setText(q1);
		this.question2Lbl.setText(q2);
		this.question3Lbl.setText(q3);
		this.question4Lbl.setText(q4);
		this.question5Lbl.setText(q5);
	}

	public void setOverallMarkLabel(int overallMark){
		this.overallMark.setText("" + overallMark);
	}

	public ImageView getImageView1() {
		return iv1;
	}
	public void setImageView1(Image img) {
		iv1.setImage(img);
	}
	public ImageView getImageView2() {
		return iv2;
	}
	public void setImageView2(Image img) {
		iv2.setImage(img);
	} 
	public ImageView getImageView3() {
		return iv3;
	}
	public void setImageView3(Image img) {
		iv3.setImage(img);
	} 
	public ImageView getImageView4() {
		return iv4;
	}
	public void setImageView4(Image img) {
		iv4.setImage(img);
	} 
	public ImageView getImageView5() {
		return iv5;
	}
	public void setImageView5(Image img) {
		iv5.setImage(img);
	} 
	public ComboBox<String> getCombobox1() {
		return answer1Cmb;
	}
	public ComboBox<String> getCombobox2() {
		return answer2Cmb;
	}
	public ComboBox<String> getCombobox3() {
		return answer3Cmb;
	}
	public ComboBox<String> getCombobox4() {
		return answer4Cmb;
	}
	public ComboBox<String> getCombobox5() {
		return answer5Cmb;
	}
	public Button getMarkQuestionnaireBtn() {
		return markQuestionnaireBtn;
	}

	public void addBackToTopicsBtnEventHandler(EventHandler<ActionEvent> handler){
		backToTopicsBtn.setOnAction(handler);
	}

	public void addMarkQuestionnaireBtnEventHandler(EventHandler<ActionEvent> handler){
		markQuestionnaireBtn.setOnAction(handler);
	}


}
