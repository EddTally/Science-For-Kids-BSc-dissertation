package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class ChoosingSubjectPane extends BorderPane{

	private Label studyYear;
	private Button physicsBtn, biologyBtn, chemistryBtn, goBackBtn, logoutBtn;
	
	public ChoosingSubjectPane(){
		
		GridPane gp = addGridPane();

		studyYear = new Label();
		studyYear.setPadding(new Insets(30, 30, 30, 30));
		studyYear.setFont(Font.font("Arial", 30));
		BorderPane.setAlignment(studyYear, Pos.CENTER);

		this.setTop(studyYear);
		this.setCenter(gp);
		this.setPadding(new Insets(20, 20, 20, 20));
		
	}
	
public GridPane addGridPane() {
		
		GridPane gp = new GridPane();
		
		gp.setPadding(new Insets(10, 10, 10, 10));
		gp.setVgap(30);
		gp.setHgap(30);
		gp.setAlignment(Pos.CENTER);
		//gp.setGridLinesVisible(true);
		
		physicsBtn = new Button("Physics");
		physicsBtn.setFont(Font.font("Arial", 30));
		physicsBtn.setPrefSize(600, 100);
		physicsBtn.setId("physicsBtn");
		
		biologyBtn = new Button("Biology");
		biologyBtn.setFont(Font.font("Arial", 30));
		biologyBtn.setPrefSize(600, 100);
		biologyBtn.setId("biologyBtn");
		
		chemistryBtn = new Button("Chemistry");
		chemistryBtn.setFont(Font.font("Arial", 30));
		chemistryBtn.setPrefSize(600, 100);
		chemistryBtn.setId("chemistryBtn");
		
		logoutBtn = new Button("Logout");
		logoutBtn.setPadding(new Insets(10,10,10,10));
		
		goBackBtn = new Button("Go Back");
		goBackBtn.setPadding(new Insets(10,10,10,10));

		
		
		gp.add(physicsBtn, 1, 0);
		gp.add(biologyBtn, 1, 1);
		gp.add(chemistryBtn, 1, 2);
		gp.add(logoutBtn, 2, 3);
		gp.add(goBackBtn, 0, 3);
		
		return gp;
	}
	
	public void setStudyYear(int studyYear){
		this.studyYear.setText("You Chose Year " + studyYear);
	}
	
	public void addPhysicsEventHandler(EventHandler<ActionEvent> handler){
		physicsBtn.setOnAction(handler);
	}
	
	public void addBiologyEventHandler(EventHandler<ActionEvent> handler){
		biologyBtn.setOnAction(handler);
	}
	
	public void addChemistryEventHandler(EventHandler<ActionEvent> handler){
		chemistryBtn.setOnAction(handler);
	}
	
	public void addGoBackEventHandler(EventHandler<ActionEvent> handler){
		goBackBtn.setOnAction(handler);
	}
	
	public void addLogoutBtnEventHandler(EventHandler<ActionEvent> handler){
		logoutBtn.setOnAction(handler);
	}
	
}
