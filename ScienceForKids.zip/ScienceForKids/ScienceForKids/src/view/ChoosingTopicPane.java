package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class ChoosingTopicPane extends BorderPane{

	private Label subjectAndStudyYearLbl;
	private ListView<String> listView;
	private Button goBackBtn, logoutBtn;

	public ChoosingTopicPane(){
		GridPane gp = addGridPane();

		subjectAndStudyYearLbl = new Label();
		subjectAndStudyYearLbl.setPadding(new Insets(30, 30, 30, 30));
		subjectAndStudyYearLbl.setFont(Font.font("Arial", 30));	

		this.setTop(subjectAndStudyYearLbl);
		this.setCenter(gp);
		this.setPadding(new Insets(10, 10, 10, 10));
	}



	public GridPane addGridPane() {

		GridPane gp = new GridPane();
		gp.setPadding(new Insets(10, 10, 10, 10));
		gp.setVgap(30);
		gp.setHgap(30);
		gp.setAlignment(Pos.CENTER);
		//gp.setGridLinesVisible(true);

		listView = new ListView<String>();
		listView.setId("choosingTopicView");

		logoutBtn = new Button("Logout");
		logoutBtn.setPadding(new Insets(10,10,10,10));

		goBackBtn = new Button("Back");
		goBackBtn.setPadding(new Insets(10,10,10,10));

		gp.add(listView, 1, 0);
		gp.add(goBackBtn, 0, 1);
		gp.add(logoutBtn, 2, 1);


		return gp;
	}


	public String getTopicChosen(){
		return listView.getSelectionModel().getSelectedItem();
	}

	public void setSubjectAndStudyYearChosenLbl(int studyYear, String subjectChosenLbl){
		this.subjectAndStudyYearLbl.setText("Year " + studyYear + " " + subjectChosenLbl);
	}

	public void addGoBackBtnEventHandler(EventHandler<ActionEvent> handler){
		goBackBtn.setOnAction(handler);
	}

	public ListView<String> getTopicListView(){
		return listView;
	}

	public void addLogoutEventHandler(EventHandler<ActionEvent> handler){
		logoutBtn.setOnAction(handler);
	}
	public void addTopicChosenEventHandler(EventHandler<MouseEvent> handler){
		listView.setOnMouseClicked(handler);
		//Find way to extract which topic, maybe loop through topics in database and assign a button to each one
	}


}
