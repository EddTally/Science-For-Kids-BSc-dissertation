package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Font;

public class LevelOfStudyPane extends BorderPane{
	
	private Label usernameLbl;
	private Button year4Btn, year5Btn, year6Btn, year7Btn, logoutBtn;
	
	public LevelOfStudyPane(){

		FlowPane fp = addFlowPane();
		
		usernameLbl = new Label("Welcome");
		usernameLbl.setPadding(new Insets(30, 30, 30, 30));
		usernameLbl.setFont(Font.font("Arial", 30));
		BorderPane.setAlignment(usernameLbl, Pos.CENTER);
		
		
		this.setTop(usernameLbl);
		this.setCenter(fp);
		this.setBottom(logoutBtn);
		
	}
	
	public FlowPane addFlowPane() {
		
		FlowPane fp = new FlowPane();
		
		fp.setPadding(new Insets(10, 10, 10, 10));
		fp.setVgap(30);
		fp.setHgap(30);
		//fp.setStyle("-fx-background-color: DAE6F3;");
		fp.setAlignment(Pos.CENTER);
		
		year4Btn = new Button("Year 4");
		year4Btn.setPadding(new Insets(30, 30, 30, 30));
		year4Btn.setFont(Font.font("Arial", 30));
		
		year5Btn = new Button("Year 5");
		year5Btn.setPadding(new Insets(30, 30, 30, 30));
		year5Btn.setFont(Font.font("Arial", 30));
		
		year6Btn = new Button("Year 6");
		year6Btn.setPadding(new Insets(30, 30, 30, 30));
		year6Btn.setFont(Font.font("Arial", 30));
		
		year7Btn = new Button("Year 7");
		year7Btn.setPadding(new Insets(30, 30, 30, 30));
		year7Btn.setFont(Font.font("Arial", 30));
		
		
		fp.getChildren().addAll(year4Btn, year5Btn, year6Btn, year7Btn);
		
		
		logoutBtn = new Button("Logout");
		logoutBtn.setPadding(new Insets(10,10,10,10));
		
		return fp;
	}
	
	
	public void setUsernameLabel(String usernameLabel){
		this.usernameLbl.setText(usernameLabel);
	}
	
	public void addLogoutEventHandler(EventHandler<ActionEvent> handler){
		logoutBtn.setOnAction(handler);
	}
	public void addYear4EventHandler(EventHandler<ActionEvent> handler){
		year4Btn.setOnAction(handler);
	}
	public void addYear5EventHandler(EventHandler<ActionEvent> handler){
		year5Btn.setOnAction(handler);
	}
	public void addYear6EventHandler(EventHandler<ActionEvent> handler){
		year6Btn.setOnAction(handler);
	}
	public void addYear7EventHandler(EventHandler<ActionEvent> handler){
		year7Btn.setOnAction(handler);
	}

}
