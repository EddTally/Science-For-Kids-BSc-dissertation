package view;

import javafx.scene.layout.BorderPane;

public class ScienceForKidsRootPane extends BorderPane{

	private MainScreenPane mainScreenP;
	private LoginScreenPane loginScreenP;
	private LevelOfStudyPane levelOfStudyP;
	private ChoosingSubjectPane choosingSubjectP;
	private ChoosingTopicPane choosingTopicP;
	private LearningScreenPane learningScreenP;
	private YoungerQuizPane youngerQuizP;
	private OlderQuizPane olderQuizP;
	
	public ScienceForKidsRootPane(){
		
		mainScreenP = new MainScreenPane();
		loginScreenP = new LoginScreenPane();
		levelOfStudyP = new LevelOfStudyPane();
		choosingSubjectP = new ChoosingSubjectPane();
		choosingTopicP = new ChoosingTopicPane();
		learningScreenP = new LearningScreenPane();
		youngerQuizP = new YoungerQuizPane();
		olderQuizP = new OlderQuizPane();	
		

		this.setCenter(mainScreenP);

		
	}
	
	public MainScreenPane getMainScreenPane(){
		return mainScreenP;
	}
	
	public LoginScreenPane getLoginScreenPane(){
		return loginScreenP;
	}
	
	public LevelOfStudyPane getLevelOfStudyPane(){
		return levelOfStudyP;
	}
	
	public ChoosingSubjectPane getChoosingSubjectPane(){
		return choosingSubjectP;
	}
	
	public ChoosingTopicPane getChoosingTopicPane(){
		return choosingTopicP;
	}
	
	public LearningScreenPane getLearningScreenPane(){
		return learningScreenP;
	}
	
	public YoungerQuizPane getYoungerQuizPane(){
		return youngerQuizP;
	}
	
	public OlderQuizPane getOlderQuizPane(){
		return olderQuizP;
	}
	
	public void setPane(BorderPane pane) {
		this.setCenter(pane);
	}
	
}
