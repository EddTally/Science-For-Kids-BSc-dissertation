package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class MainScreenPane extends BorderPane{
	
	private TextField newUsername;
	private Button registerBtn, guestBtn, loginBtn;
	private PasswordField newPassword, passwordCheck;
	
	
	public MainScreenPane(){		


		GridPane lgp = leftGridPane();
		GridPane rgp = rightGridPane();
		GridPane tgp = topGridPane();
		this.setLeft(lgp);
		this.setRight(rgp);
		this.setTop(tgp);
		this.setMaxSize(1000, 700);		
		this.setPadding(new Insets(20, 20, 20, 20));

	}

	//Top of page
	public GridPane topGridPane() {
		
		GridPane gp = new GridPane();
		//gp.setGridLinesVisible(true);

		
		Label title = new Label("Science for Kids");
		title.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		
		gp.add(title, 0, 0);
		gp.setAlignment(Pos.CENTER);
		
		return gp;
	}

	//left Side of page
	public GridPane leftGridPane() {
		
		GridPane gp = new GridPane();
		gp.setVgap(8);
		gp.setHgap(15);
		gp.setAlignment(Pos.CENTER);
		gp.setMaxWidth(500);
		//gp.setGridLinesVisible(true);
		
		/*Description For Register Process */
		Label regDesc = new Label("Want to track your completed topic & scores but you don't have an account?"
				+ " Sign Up!");
		regDesc.setWrapText(true);
		regDesc.setFont(Font.font("Arial", 20));
		
		/*Username and Password Labels and TextFields */
		Label usernameLbl = new Label("Username: ");		
		Label passwordLbl = new Label("Password: ");
		Label passwordCheckLbl = new Label("Re enter password: ");
		
		newUsername = new TextField();
		newUsername.setMaxWidth(150);
		newUsername.setPromptText("username");
		
		newPassword = new PasswordField();
		newPassword.setMaxWidth(150);
		newPassword.setPromptText("password");
		
		passwordCheck = new PasswordField();
		passwordCheck.setMaxWidth(150);
		passwordCheck.setPromptText("password");
		
		/*Register Button*/		
		registerBtn = new Button("Register");
		registerBtn.setDefaultButton(true);
		registerBtn.setTranslateY(25);
		
		//Adding stuff to columns		
		gp.add(regDesc, 0, 0, 2, 1);
		gp.add(usernameLbl, 0, 2, 1, 1);
		gp.add(newUsername, 1, 2, 1, 1);
		gp.add(passwordLbl, 0, 3, 1, 1);
		gp.add(newPassword, 1, 3, 1, 1);
		gp.add(passwordCheck, 1, 4, 1, 1);
		gp.add(passwordCheckLbl, 0, 4, 1, 1);
		gp.add(registerBtn, 1, 5, 1, 1);		
		
		
		return gp;
	}
	
	//Right Side of Page
	public GridPane rightGridPane() {
		
		GridPane gp = new GridPane();
		gp.setVgap(8);
		gp.setHgap(15);
		gp.setAlignment(Pos.CENTER);
		gp.setMaxWidth(500);
		gp.setStyle("-fx-font: 20px \"Arial\";");
		//gp.setGridLinesVisible(true);
		gp.setTranslateY(-15); //Gets it in line with the left gridPane

		/*Description and Button for guest users*/
		Label guestDesc = new Label("Want to learn without any strings attached?\n"
				+ "Just continue as a guest for full access to learning material & end of unit quizzes!");
		guestDesc.setWrapText(true);
		guestDesc.setFont(Font.font("Arial", 20));

		guestBtn = new Button("Continue as guest");
		guestBtn.setPadding(new Insets(5, 10, 5, 10));

		/*Description for Login and Login Button*/
		Label loginDesc = new Label("Or if you already have an account, Login!");
		loginDesc.setFont(Font.font("Arial", 20));
		
		loginBtn = new Button("Login");
		loginBtn.setPadding(new Insets(5, 10, 5, 10));

		gp.add(guestDesc, 0, 0, 2, 1);
		gp.add(guestBtn, 0, 2, 2, 1);
		gp.add(loginDesc, 0, 3, 2, 1);
		gp.add(loginBtn, 0, 5, 2, 1);

		return gp;

	}



	public String getNewUsername(){
		return newUsername.getText();
	}
	public TextField getNewUsernameField() {
		return newUsername;
	}

	public String getNewPassword(){
		return newPassword.getText();
	}
	public PasswordField getNewPasswordField() {
		return newPassword;
	}
	
	public String getPasswordCheck() {
		return passwordCheck.getText();
	}
	public PasswordField getPasswordCheckField() {
		return passwordCheck;
	}

	public void addCreateUserEventHandler(EventHandler<ActionEvent> handler){
		registerBtn.setOnAction(handler);
	}

	public void addGuestEventHandler(EventHandler<ActionEvent> handler){
		guestBtn.setOnAction(handler);
	}

	public void addMainScreenLoginEventHandler(EventHandler<ActionEvent> handler){
		loginBtn.setOnAction(handler);
	}


}