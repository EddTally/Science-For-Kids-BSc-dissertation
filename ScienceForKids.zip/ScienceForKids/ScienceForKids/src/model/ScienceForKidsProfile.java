package model;

import java.io.Serializable;

public class ScienceForKidsProfile implements Serializable {
	

	private User user;
	private Topic topic;
	private Question question;
	private Questionnaire questionnaire;
	private int totalMark;
	
	public ScienceForKidsProfile() {
		user = new User();
		topic = new Topic();
		question = new Question();
		questionnaire = null;
		totalMark = 0;
	}
	
	
	public void setUser(User user) {
		this.user = user;
	}
	public User getUser(){
		return user;
	}
	
	public void setTopic(Topic topic) {
		this.topic = topic;
	}
	
	public Topic getTopic() {
		return this.topic;
	}
	
	public int getTotalMark() {
		return totalMark;
	}
	
	public void setTotalMark(int totalMark) {
		this.totalMark += totalMark;
	}
	public void resetTotalMark() {
		totalMark = 0;
	}
	
	public void setQuestion(Question question) {
		this.question = question;
	}
	
	public Question getQuestion() {
		return question;
	}
	
	public Questionnaire getQuestionnnaire() {
		return questionnaire;
	}
	public void setQuestionnaire(Questionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

}
