package model;

import java.io.Serializable;

public class Topic implements Serializable{
	
	private int subjectYear, topicId, topicSplitNumber, topicSplitDisplayCount;
	private String topicName, topicContents, subject;
	private String[] splitTopicContents;
	
	public Topic() {
		topicId = 0;
		topicName = "";
		topicContents = "";
		subjectYear = 0;
		subject = "";
		splitTopicContents = null;
		topicSplitNumber = 0;
		topicSplitDisplayCount = 0;
	}
	

	public Topic(int topicId, String topicName, String topicContents, int subjectYear, String subject) {
		this.topicId = topicId;
		this.topicName = topicName;
		this.topicContents = topicContents;
		this.subjectYear = subjectYear;
		this.subject = subject;
	}
	
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}

	public int getSubjectYear() {
		return subjectYear;
	}
	
	public void setSubjectYear(int subjectYear) {
		this.subjectYear = subjectYear;
	}
	
	public String getTopicName() {
		return topicName;
	}
	
	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}
	
	public String getTopicContents() {
		return topicContents;
	}
	
	public void setTopicContents(String topicContents) {
		this.topicContents = topicContents;
	}
	
	public String getSubject() {
		return subject;
	}
	
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/** topicsSplitNumber defines the number of different parts of the topic
	 * that need to be displayed, it is a count for the amount of times the
	 * next page button is needed.
	 * @param topicSplitNumber
	 */
	public int getTopicSplitNumber() {
		return topicSplitNumber;
	}

	public void setTopicSplitNumber(int topicSplitNumber) {
		this.topicSplitNumber = topicSplitNumber;
	}

	public String[] getSplitTopicContents() {
		return splitTopicContents;
	}

	public void setSplitTopicContents(String[] splitTopicContents) {
		this.splitTopicContents = splitTopicContents;
	}
	
	/** topicSplitDisplayCount this is included to be able to save the amount of times the
	 * next page button has been pushed so we can compare it against the topicSplitNumber
	 * to see how many more times a new page needs to be loaded in.
	 * @param topicSplitDisplayCount
	 */
	public int getTopicSplitDisplayCount() {
		return topicSplitDisplayCount;
	}

	public void setTopicSplitDisplayCount(int topicSplitDisplayCount) {
		this.topicSplitDisplayCount = topicSplitDisplayCount;
	}
	
	
	
}
