package model;

import java.io.Serializable;

public class User implements Serializable{
	
	private String username, password, topicsCompleted;
	private int userId, totalMarks;
	
	
	public User() {
		userId = 0;
		username = "";
		password = "";	
		totalMarks = 0;
		topicsCompleted = "";
	}
	
	public User(int userId, String username, String password, int totalMarks, String topicsCompleted) {
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.totalMarks = totalMarks;
		this.topicsCompleted = topicsCompleted;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public int getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
	
	public String getTopicsCompleted() {
		return topicsCompleted;
	}
	
	public void setCompletedTopics(String topicsCompleted) {
		this.topicsCompleted = topicsCompleted;
	}

	@Override
	public String toString() {
		return "User: \nuserId: " + userId + "\nusername: " + username + "\npassword: " + password
				+ "\ntopicsCompleted: " + topicsCompleted + "\ntotalMarks: " + totalMarks;
	}

}
