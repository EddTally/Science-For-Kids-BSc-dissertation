package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Questionnaire implements Serializable{
	
	private List<Question> questions;
	
	public Questionnaire() {
		questions = new ArrayList<Question>();
		
	}
	public void addQuestion(Question question) {
		this.questions.add(question);
	}
	
	public Question getQuestionByQuestionNumber(int questionNumber) {
		return questions.get(questionNumber);
	}
	
	public void resetQuestionnaire() {
		questions.clear();
	}

	@Override
	public String toString() {
		return "\nQuestions: \n" + questions;
	}

}
