package model;

import java.io.Serializable;

import javafx.scene.image.Image;

public class Question implements Serializable{
	
	private int questionNumber;
	private String questionText, questionAnswer, multipleChoiceAnswers;
	private Boolean questionAttempted;
	private Image questionImg;
	
	public Question() {
		questionNumber = 1;
		questionText = "";
		questionAnswer = "";
		multipleChoiceAnswers = "";
		questionAttempted = false;
		questionImg = null;
	}
	
	public Question(int questionNumber, String questionText, 
			String questionAnswer, String multipleChoiceAnswers, Boolean questionAttempted, Image questionImg) {
		this.questionNumber = questionNumber;
		this.questionText = questionText;
		this.questionAnswer = questionAnswer;
		this.multipleChoiceAnswers = multipleChoiceAnswers;
		this.questionAttempted = questionAttempted;
		this.questionImg = questionImg;
	}
	
	public int getQuestionNumber() {
		return questionNumber;
	}
	
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
	
	public String getQuestionText() {
		return questionText;
	}
	
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	
	public String getQuestionAnswer() {
		return questionAnswer;
	}
	
	public void setQuestionAnswer(String questionAnswer) {
		this.questionAnswer = questionAnswer;
	}
	
	public Boolean getQuestionAttempted() {
		return questionAttempted;
	}
	
	public void setQuestionAttempted(Boolean questionAttempted) {
		this.questionAttempted = questionAttempted;
	}
	
	public String getMultipleChoiceAnswers() {
		return multipleChoiceAnswers;
	}
	
	public void setMultipleChoiceAnswers(String multipleChoiceAnswers) {
		this.multipleChoiceAnswers = multipleChoiceAnswers;
	}
	
	public Image getQuestionImage() {
		return questionImg;
	}
	
	public void setQuestionImage(Image image) {
		this.questionImg = image;

	}
	

	@Override
	public String toString() {
		return "Question: QuestionNumber=" + questionNumber + ", QuestionText=" + questionText + ", QuestionAnswer="
				+ questionAnswer + ", MultipleChoiceAnswers=" + multipleChoiceAnswers + ", QuestionAttempted="
				+ questionAttempted + "\n";
	}
	
	

}
